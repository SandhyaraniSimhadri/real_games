


const scriptsInEvents = {

	async Events_game_Event95_Act17(runtime, localVars)
	{
		
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

