


const scriptsInEvents = {

	async Events_game_Event95_Act18(runtime, localVars)
	{
		
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

